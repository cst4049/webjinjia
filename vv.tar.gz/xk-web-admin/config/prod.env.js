'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://172.17.12.3"',
  PORT: 5002
}
