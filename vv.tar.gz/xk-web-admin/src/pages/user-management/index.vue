<template>
  <div>
    <header>导航栏</header>
    <main>
      <!-- S 面包屑 -->
      <div class="breadcrumb">
        <div class="uri-desc">
          <p>{{ uriDesc }}</p>
        </div>
        <div class="operation">
          <button @click="openModal('add')">新增用户</button>
        </div>
      </div>
      <!-- E 面包屑 -->

      <!-- S 过滤条件 -->
      <div class="filter">
        <div>
          <!-- 按角色 -->
          <select v-model="selectedRole">
            <option v-for="(role, index) in roles" :key="index" :value="role.name">
              {{ role.title }}
            </option>
          </select>

          <!-- 按学科 -->
          <select v-model="selectedSubject">
            <option v-for="(subject, index) in subjects" :key="index" :value="subject.name">
              {{ subject.title }}
            </option>
          </select>

          <!-- 按状态 -->
          <select v-model="selectedState">
            <option v-for="(state, index) in states" :key="index" :value="state.name">
              {{ state.title }}
            </option>
          </select>
        </div>

        <div>
          <!-- <input type="text" class="input-search" placeholder="输入关键词..."> -->
          <a href="javascript: void(0)" @click="getUser()">
            <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
            <span>查询</span>
          </a>
          <a href="javascript: void(0)" class="plain" @click="resetFilter()">清除查询</a>
        </div>
      </div>
      <!-- E 过滤条件 -->

      <!-- S 用户表格 -->
      <table class="user" cellpadding="0" cellspacing="0">
        <thead>
          <th v-for="(tableHeader, index) in tableHeaders" :key="index">{{ tableHeader }}</th>
        </thead>

        <tbody>
          <tr v-for="(user, index) in diplayedUsers" :key="index">
            <td>{{ userIndex + index + 1 }}</td>
            <td>{{ user._id }}</td>
            <td>{{ user.name }}</td>
            <td>{{ user.primaryRole }}</td>
            <td>{{ user.primaryDiscipline }}</td>
            <td :class="{red: !user.active}">{{ user.active ? '有效': '无效' }}</td>

            <td>
              <button @click="openResetPwdModal(user)">重置密码</button>
              <button class="dark" @click="openModal('edit', user)">编辑用户</button>
              <button class="red" @click="openDeleteModal(user)">删除</button>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- E 用户表格 -->

      <!-- S 分页 -->
      <div class="pagination">
        <div>
          <span>显示</span>
          <select v-model="pageSize">
            <option v-for="(pageSize, index) in pageSizes" :key="index" :value="pageSize">{{ pageSize }}</option>
          </select>
          <span>条记录，</span>
          <span>当前显示{{ users.length > 0 ? userIndex + 1 : 0}}到{{ (page * pageSize) > users.length ? users.length : (page * pageSize) }}条，</span>
          <span>共{{ users.length }}条记录</span>
        </div>

        <div>
          <span @click="setPage('-')" :class="{ disabled: page === 1 }">上一页</span>

          <span v-if="page - 3 > 0" @click="setPage(page - 3)">{{ page - 3 }}</span>
          <span v-if="page - 2 > 0" @click="setPage(page - 2)">{{ page - 2 }}</span>
          <span v-if="page - 1 > 0" @click="setPage(page - 1)">{{ page - 1 }}</span>

          <span class="active" v-if="page <= totalPage">{{ page }}</span>

          <span v-if="page + 1 < totalPage" @click="setPage(page + 1)">{{ page + 1 }}</span>
          <span v-if="page + 2 < totalPage" @click="setPage(page + 2)">{{ page + 2 }}</span>
          <span v-if="page + 3 < totalPage" @click="setPage(page + 3)">{{ page + 3 }}</span>

          <span v-if="page < totalPage" @click="setPage(totalPage)">{{ totalPage }}</span>

          <span @click="setPage('+')" :class="{ disabled: page === totalPage || totalPage < 1 }">下一页</span>
        </div>
      </div>
      <!-- E 分页 -->
    </main>

    <modal 
      :title="uriDesc + ' > ' + modalTitle" 
      v-if="showModal"
      @ok="addUser()(modalTitle)"
      @cancel="closeModal">
        <div class="form-group">
          <!-- 角色 -->
          <select class="form-control" v-model="targetUser.role" :class="{ empty: !targetUser.role && tryToSubmit }">
            <option disabled value="">请选择</option>
            <option v-for="(role, index) in Array.from(roles).splice(1)" :key="index" :value="{name: role.name, title: role.title}">
              {{ role.title }}
            </option>
          </select>

          <!-- 学科 -->
          <select class="form-control" v-model="targetUser.subject" :class="{ empty: !targetUser.subject && tryToSubmit }">
            <option disabled value="">请选择</option>
            <option v-for="(subject, index) in Array.from(subjects).splice(1)" :key="index" :value="subject.name">
              {{ subject.title }}
            </option>
          </select>

          <!-- 状态 -->
          <select class="form-control" v-model="targetUser.state" :class="{ empty: !targetUser.state && tryToSubmit }">
            <option disabled value="">请选择</option>
            <option v-for="(state, index) in Array.from(states).splice(1)" :key="index" :value="state.name">
              {{ state.title }}
            </option>
          </select>
        </div>

        <div class="form-group">
          <span>用户ID</span>
          <input type="text" class="form-control" placeholder="自动生成，不可编辑" disabled="disabled" v-model="targetUser.id">
        </div>

        <div class="form-group">
          <span>姓名</span>
          <input type="text" class="form-control" placeholder="用户姓名" v-model="targetUser.name" :class="{ empty: !targetUser.name && tryToSubmit}">
        </div>

        <div class="form-group">
          <span>默认密码</span>
          <input type="text" class="form-control" disabled="disabled" v-model="targetUser.pwd">
        </div>
    </modal>

    <modal :title="uriDesc + ' > ' + '重置密码'" v-if="showResetPwdModal" @ok="resetPwd()" @cancel="closeModal">
      <div class="form-group">
        <span>新密码</span>
        <input type="text" class="form-control" v-model="newPwd">
      </div>
    </modal>

    <modal :title="uriDesc + ' > ' + '删除用户'" v-if="showDeleteModal" @ok="deleteUser()" @cancel="closeModal">
      <p class="text-red big">此操作无法撤回，是否继续？</p>
    </modal>
  </div>
</template>

<script>
import modal from '@/components/modal';
import UserService from '@/service/user-service';

export default {
  name: 'UserManagement',

  components: {
    modal
  },

  data() {
    return {
      uriDesc: '用户权限管理',
      // 所有角色
      roles: [
        {
          title: '全部角色',
          name: 0
        }
      ],
      // 选择的角色
      selectedRole: '',

      // 所有学科
      subjects: [
        {
          title: '全部学科',
          name: 0
        }
      ],
      // 选择的学科
      selectedSubject: '',

      // 所有状态
      states: [
        {
          title: '全部状态',
          code: 0,
          name: 'all'
        },

        {
          title: '激活',
          code: 1,
          name: 'active'
        },

        {
          title: '未激活',
          code: 2,
          name: 'inactive'
        }
      ],
      // 选择的状态
      selectedState: '',

      tableHeaders: ['编号', '用户ID', '用户姓名', '角色类别', '学科', '当前状态', '操作'],
      // 可用页面数量大小
      pageSizes: [20, 25, 30],
      // 当前页面数量大小
      pageSize: 20,
      // 当前页码
      page: 1,
      // 所有页数
      totalPage: '',

      // 所有用户
      users: [],
      // 展示的用户
      diplayedUsers: [],
      // 当前页码和展示数量下用户索引
      userIndex: 1,

      // 弹窗的展示控制
      showModal: false,
      modalTitle: '',
      // 进行操作的目标用户
      targetUser: {
        id: '',
        role: '',
        subject: '',
        name: '',
        state: '',
        pwd: 'YSJY123'
      },

      // 重置密码弹窗的展示控制
      showResetPwdModal: false,
      // 用户新密码
      newPwd: '',
      // 重置密码的用户的Id
      resetPwdUserId: '',

      showDeleteModal: false,
      deleteUserId: '',

      // 是否尝试提交，用于验证
      tryToSubmit: false
    }
  },

  created: function () {
    this.listUser();

    UserService.listRole()
      .then(data => {
        this.roles = this.roles.concat(data._items);
        this.selectedRole = this.roles[0].name;
      });

    UserService.listSubject()
      .then(data => {
        this.subjects = this.subjects.concat(data.literal);
        this.selectedSubject = this.subjects[0].name;
        this.selectedState = this.states[0].name;
      });
  },

  watch: {
    page(newPage) {
      this.setDisplayedUser();
    },

    pageSize(newPageSize) {
      this.page = 1;
      this.setDisplayedUser();
    },

    users(newUsers) {
      this.setDisplayedUser();
    }
  },

  methods: {
    // 获取所有用户
    listUser() {
      UserService.listUser()
        .then(data => {
          this.users = data._items;
        });
    },

    // 查询用户
    getUser() {
      const primaryRole = (this.selectedRole === 0) ? '' : this.selectedRole;
      const primaryDiscipline = (this.selectedSubject === 0) ? '' : this.selectedSubject;
      let active = false;

      switch (this.selectedState) {
        case 'all':
          active = '';
          break;

        case 'inactive':
          active = false;
          break;

        case 'active':
          active = true;
          break;
      }

      if (!primaryRole && !primaryDiscipline && active === '') {
        UserService.listUser()
          .then(data => {
            this.users = data._items;
            this.setPage(1);
          });
      } else {
        UserService.getUser({primaryRole, primaryDiscipline, active})
          .then(data => {
            this.users = data._items;
            this.setPage(1);
          });
      }
    },

    // 清除查询
    resetFilter() {
      this.selectedRole = this.roles[0].name;
      this.selectedSubject = this.subjects[0].name;
      this.selectedState = this.states[0].name;
    },

    // 打开弹窗
    openModal(type, user = {}) {
      switch (type) {
        case 'add':
          this.modalTitle = '新增用户';
          break;

        case 'edit':
          this.modalTitle = '编辑用户';

          this.targetUser.name = user.name;
          this.targetUser.id = user._id;
          this.targetUser.role = {
            title: user.description,
            name: user.primaryRole
          };
          this.targetUser.subject = user.primaryDiscipline;
          this.targetUser.state = user.active ? 'active' : 'inactive';

          break;
      }

      this.showModal = true;
    },

    // 打开重置密码弹窗
    openResetPwdModal(user) {
      this.showResetPwdModal = true;
      this.resetPwdUserId = user._id;
    },

    resetPwd() {
      UserService.modifyUserPwd(this.resetPwdUserId, this.newPwd)
        .then(data => {
          this.closeModal();
          this.$notify({
            type: 'success',
            title: '成功',
            msg: '重置密码成功'
          });
        })
        .catch(err => {
          this.$notify({
            type: 'fail',
            title: '失败',
            msg: '重置密码失败'
          });
        })
    },

    // 打开删除用户弹窗
    openDeleteModal(user) {
      this.showDeleteModal = true;
      this.deleteUserId = user._id;
    },

    // 删除用户
    deleteUser() {
      UserService.deleteUser(this.deleteUserId)
        .then(data => {
          this.$notify({
            type: 'success',
            title: '成功',
            msg: '删除用户成功'
          });

          this.closeModal();
          this.$nextTick(this.listUser());
        })
        .catch(err => console.log(err))
    },

    closeModal() {
      this.showModal = false;
      this.showResetPwdModal = false;
      this.showDeleteModal = false;

      this.targetUser = {
        id: '',
        role: '',
        subject: '',
        name: '',
        state: '',
        pwd: 'YSJY123'
      };
      this.newPwd = '';
    },

    // 新增用户
    addUser() {
      let active = this.targetUser.state === 'active' ? true : false;
      
      const newUser = {
        "name": this.targetUser.name,
        "description": this.targetUser.role.title,
        "active": active,
        "role": [].concat(this.targetUser.role.name),
        "primaryRole": this.targetUser.role.name,
        "discipline": [].concat(this.targetUser.subject),
        "primaryDiscipline": this.targetUser.subject,
        "passwd": this.targetUser.pwd
      };

      let flag = true;
      // 字段检测，均不得为空
      Object.keys(newUser).some(key => {
        if (!newUser[key]) {
          if (key === 'active') { // 不检测active属性
            return true;
          }

          flag = false;
        }
      });

      return (type) => {
        this.tryToSubmit = true;

        if (!flag) {
          return;
        }

        switch (type) {
          case '新增用户':
            UserService.addUser(newUser)
              .then(data => {
                this.closeModal();
                this.$notify({
                  type: 'success',
                  title: '成功',
                  msg: '新增用户成功'
                });
                this.listUser();
              })
              .catch(err => {
                this.$notify({
                  type: 'fail',
                  title: '失败',
                  msg: '新增用户失败'
                });
              });
            break;
          
          case '编辑用户':
            UserService.modifyUserName(this.targetUser.id, newUser).then(data => {
              this.closeModal();
              this.$notify({
                type: 'success',
                title: '成功',
                msg: '修改成功'
              });
              this.listUser();
            })
            .catch(err => {
                this.$notify({
                  type: 'fail',
                  title: '失败',
                  msg: '修改失败，用户姓名已存在'
                });
              });
            break;
        }
      }
    },

    setPage(signal) {
      switch (signal) {
        case '-' :
          this.page = this.page > 2 ? --this.page : 1;
          break;

        case '+' :
          this.page = (this.page < this.totalPage && this.totalPage > 1) ? ++this.page : this.totalPage;
          this.page = this.page > 1 ? this.page : 1;
          break;

        default:
          this.page = signal;
          break;
      }
    },

    // 根据页码和展示数量来设置展示的用户
    setDisplayedUser() {
      const users = Array.from(this.users);

      this.diplayedUsers = users.splice(((this.page - 1) * this.pageSize), this.pageSize);
      this.userIndex = (this.page - 1) * this.pageSize;

      this.totalPage = ~~(this.users.length / this.pageSize) + 1;
    }
  }
}
</script>

<style lang="scss" scoped>
@import './index.scss';
</style>
