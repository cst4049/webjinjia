const token = window.localStorage.getItem('token') || '';

export { token };
