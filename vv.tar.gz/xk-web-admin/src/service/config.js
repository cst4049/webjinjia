import axios from 'axios';
import { token } from './token';
import router from '../router/index';

// API接口地址及端口
const API_ROOT = process.env.API_ROOT;
const PORT = process.env.PORT;

axios.defaults.timeout = 5000;
axios.defaults.baseURL = `${API_ROOT}:${PORT}/`;

// 请求拦截
axios.interceptors.request.use(req => {
  let hasQuestionMark = req.url.includes('?');
  let hasToken = req.url.includes('token');

  if (hasQuestionMark && !hasToken) {
    req.url += '&token=' + token;
  } else if (!hasQuestionMark && !hasToken) {
    req.url += '?token=' + token;
  }

  return req;
}, err => Promise.reject(err));

// 响应拦截
axios.interceptors.response.use(res => {
  if (!(/^2/).test(res.status)) {
    Promise.reject(res);
  }

  return res.data; // 200 OK
}, err => {
  if (err.response.status == 401) {
    router.push('/login');
  }

  Promise.reject(err)
});

export default axios;
