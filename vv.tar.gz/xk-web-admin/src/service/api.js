const User = {
  getUser: 'users/',
  listRole: 'roles/',
  listSubject: 'mm/enums/QuestionDisciplineKind'
};

export { User };
