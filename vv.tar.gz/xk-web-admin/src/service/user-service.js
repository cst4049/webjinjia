import axios from './config';
import {User} from './api';

const UserService = {};

/**
 * 获取全部用户
 * @param {String} token
 * @return {Object} 返回值
 */
UserService.listUser = () => {
  const header = {
    headers: {"Cache-Control": "no-cache"}
  };

  return new Promise((resolve, reject) => {
    axios.get(`${User.getUser}`, header)
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 查询用户
 * @param {Object} 查询条件
 */
UserService.getUser = ({primaryRole, primaryDiscipline, active}) => {
  let query = '{';
  if (primaryRole) {
    query += `"primaryRole": "${primaryRole}"${primaryDiscipline || (active !== '') ? ',' : ''}`;
  }

  if (primaryDiscipline) {
    query += `"primaryDiscipline": "${primaryDiscipline}"${active !== '' ? ',' : ''}`;
  }

  if (active !== '') {
    query += `"active": ${!!active}`;
  }

  query += '}';

  const header = {
    headers: {"Cache-Control": "no-cache"}
  };

  return new Promise((resolve, reject) => {
    axios.get(`${User.getUser}?where=${query}`, header)
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 新增用户
 * @param {*} newUser 
 */
UserService.addUser = (newUser) => {
  return new Promise((resolve, reject) => {
    axios.post(`${User.getUser}`, {
      "name": newUser.name,
      "description": newUser.description,
      "active": newUser.active,
      "role": newUser.role,
      "primaryRole": newUser.primaryRole,
      "discipline": newUser.discipline,
      "primaryDiscipline": newUser.primaryDiscipline,
      "passwd": newUser.passwd
    })
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 更改用户姓名
 * @param {Staing} uId 用户id 
 * @param {String} name 用户姓名 
 */
UserService.modifyUserName = (uId, newUser) => {
  return new Promise((resolve, reject) => {
    axios.patch(`${User.getUser}${uId}/`, {
      "name": newUser.name,
      "description": newUser.description,
      "active": newUser.active,
      "role": newUser.role,
      "primaryRole": newUser.primaryRole,
      "discipline": newUser.discipline,
      "primaryDiscipline": newUser.primaryDiscipline
    })
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 更改用户密码
 * @param {Staing} uId 用户id 
 * @param {String} newPwd 用户新密码
 */
UserService.modifyUserPwd = (uId, newPwd) => {
  return new Promise((resolve, reject) => {
    axios.patch(`${User.getUser}${uId}/passwd/`, {
      "passwd": newPwd
    })
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 删除指定用户
 * @param {String} uId 
 */
UserService.deleteUser = (uId) => {
  return new Promise((resolve, reject) => {
    axios.delete(`${User.getUser}${uId}/`)
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 获取全部角色
 */
UserService.listRole = () => {
  return new Promise((resolve, reject) => {
    axios.get(`${User.listRole}`)
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

/**
 * 获取全部学科
 */
UserService.listSubject = () => {
  return new Promise((resolve, reject) => {
    axios.get(`${User.listSubject}`)
      .then(res => resolve(res))
      .catch(err => reject(err));
  });
}

export default UserService;
