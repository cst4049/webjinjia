import Vue from 'vue'
import Router from 'vue-router'
import { token } from '../service/token'

const lazyLoadPage = (page) => {
  return resolve => require([`@/pages/${page}/`], resolve)
}

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'UserManagement',
      component: lazyLoadPage('user-management')
    }
  ]
});

// router.beforeEach((to, from, next) => {
//   if (!token) {
//     next({
//       path: '/login'
//     });
//   } else {
//     next();
//   }
// })

export default router;
