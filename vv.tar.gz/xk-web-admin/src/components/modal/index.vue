<template>
  <transition name="slide-fade">
    <div class="container">
      <div class="rs-modal-wrapper" @click="cancel()"></div>

      <div class="rs-modal">
        <div class="rs-modal-header">
          <span>{{ title }}</span>
          <span class="glyphicon glyphicon-remove" aria-hidden="true" @click="cancel()"></span>
        </div>

        <div class="rs-modal-content">
          <slot></slot>
        </div>

        <div class="rs-modal-footer">
          <button class="btn btn-primary" @click="ok()">确认</button>
          <button class="btn btn-warning"@click="cancel()">取消</button>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'modal',
  props: {
    title: {
      type: String,
      default: '标题'
    }
  },

  methods: {
    cancel() {
      this.$emit('cancel');
    },

    ok() {
      this.$emit('ok');
    }
  }
}
</script>

<style lang="scss" scoped>
@import './index.scss'
</style>
